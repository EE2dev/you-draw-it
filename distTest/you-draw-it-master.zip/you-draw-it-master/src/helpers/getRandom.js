export function getRandom(min, max) {
  return Math.random() * (max - min) + min;
}