export const yourData = "yourData";
export const resultShown = "resultShown";
export const completed = "completed";
export const score = "score";
export const predictionDiff = "predictionDiff";
export const prediction = "prediction";
export const truth = "truth";