export const clamp = function (a, b, c) {
  return Math.max(a, Math.min(b, c));
};