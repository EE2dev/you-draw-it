
module.exports = {
  "env": {
      "browser": true,
      "commonjs": true,
      "es6": true
  },
  "extends": "eslint:recommended",
  "parserOptions": {
      "sourceType": "module"
  },
  "rules": {
      "indent": [
          "warn",
          2
      ],
      "linebreak-style": [
          "warn",
          "windows"
      ],
      "quotes": [
          "warn",
          "double"
      ],
      "no-console": 0,
      "semi": [
          "error",
          "always"
      ]
  }
};